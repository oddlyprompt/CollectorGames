#!/usr/bin/env python3
"""Puts the project's folders back. Names like src__engine__core.js become src/engine/core.js.
   Run once, from the folder these files are in:   python3 restore_folders.py"""
import os, shutil
n=0
for f in sorted(os.listdir('.')):
    if '__' in f and not f.startswith('.') and f!='restore_folders.py':
        dest=f.replace('__','/'); os.makedirs(os.path.dirname(dest),exist_ok=True); shutil.move(f,dest); n+=1
print('restored',n,'files into folders')
